package sg.edu.nuss.iss.d11lecture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D11lectureApplication {

	public static void main(String[] args) {
		SpringApplication.run(D11lectureApplication.class, args);
	}

}
