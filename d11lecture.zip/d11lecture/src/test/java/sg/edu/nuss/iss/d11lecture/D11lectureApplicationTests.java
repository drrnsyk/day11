package sg.edu.nuss.iss.d11lecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D11lectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
